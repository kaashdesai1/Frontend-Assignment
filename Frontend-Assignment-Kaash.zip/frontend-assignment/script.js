let addSourceModal = new bootstrap.Modal(
    document.getElementById('addSourceModal'),
    {
        keyboard: false,
    }
);

let showVideo = false;
let showScreen = false;
let cameraOn = false;

function addMedia(typeStr) {
    if (typeStr === 'screen') {
        console.log('add share screen ===');
        document.getElementById('shareMedia').style.visibility = 'visible';
        if (document.getElementById('addMedia')) {
            document.getElementById('addMedia').remove();
        }
        addSourceModal.hide();
    } else if (typeStr === 'video') {
        console.log('add video feed ===');
        cameraOn = true;
        document.getElementById('feedMedia').style.visibility = 'visible';
        if (document.getElementById('addMedia')) {
            document.getElementById('addMedia').remove();
        }
        addSourceModal.hide();
    }
}

function showOnStream(typeStr) {
    if (typeStr === 'screen') {
        console.log('show screen click ===');
        if (cameraOn && showVideo) {
            document.getElementById('first').src = './screenshare.png';

            document.getElementById('videoShowOption').style.visibility = 'hidden';
            document.getElementById('screenShowOption').style.visibility = 'visible';
            document.getElementById('screenButton1').classList.add('btn-screen-option-active', 'video-icon');

            document.getElementById('video-sm-image').style.visibility = 'visible';

            const screen = document.getElementById('screenShow');
            if (!showScreen) {
                screen.innerHTML = 'Hide on stream';
                screen.classList.remove('btn-success');
                screen.classList.add('hide-on-stream');
                showScreen = true;
            } else {
                screen.innerHTML = 'Show on stream';
                screen.classList.remove('hide-on-stream');
                screen.classList.add('btn-success');
                showScreen = false;

                if (showVideo) {
                    document.getElementById('first').src = './camera.png';
                    document.getElementById('second').style.visibility = 'hidden';
                    document.getElementById('screenLeft').style.visibility = 'hidden';
                    document.getElementById('screenRight').style.visibility = 'hidden';

                    document.getElementById('screenShowOption').style.visibility = 'hidden';
                    document.getElementById('videoShowOption').style.visibility = 'visible';
                } else {
                    document.getElementById('first').src = './black.png';
                    document.getElementById('videoShowOption').style.visibility = 'hidden';
                    document.getElementById('screenShowOption').style.visibility = 'hidden';
                }
            }
        } else {
            alert('Please turn on camera and feed it on stream.')
        }
    } else if (typeStr === 'video') {
        console.log('show video click ===');

        if (!showScreen) {
            document.getElementById('first').src = './camera.png';
            document.getElementById('videoShowOption').style.visibility = 'visible';
        }
        document.getElementById('videoButton1').classList.add('btn-light-active-1', 'video-icon');

        const video = document.getElementById('videoShow');
        if (!showVideo) {
            video.innerHTML = 'Hide on stream';
            video.classList.remove('btn-success');
            video.classList.add('hide-on-stream');
            showVideo = true;
        } else {
            video.innerHTML = 'Show on stream';
            video.classList.remove('hide-on-stream');
            video.classList.add('btn-success');
            showVideo = false;

            if (showScreen) {
                document.getElementById('first').src = './screenshare.png';
                document.getElementById('second').style.visibility = 'hidden';
                document.getElementById('screenLeft').style.visibility = 'hidden';
                document.getElementById('screenRight').style.visibility = 'hidden';

                document.getElementById('videoShowOption').style.visibility = 'hidden';
            } else {
                document.getElementById('first').src = './black.png';
                document.getElementById('videoShowOption').style.visibility = 'hidden';
                document.getElementById('screenShowOption').style.visibility = 'hidden';
            }
        }
    }
}

function changeVideoLayout(vType) {
    switch (vType) {
        case 'videoButton1':
            document.getElementById('videoButton1').classList.add('btn-light-active-1', 'video-icon');
            document.getElementById('videoButton2').classList.remove('btn-light-active-2', 'video-icon');
            document.getElementById('videoButton3').classList.remove('btn-light-active-3', 'video-icon');
            document.getElementById('first').style.border = 'none';
            break;
        case 'videoButton2':
            document.getElementById('videoButton1').classList.remove('btn-light-active-1', 'video-icon');
            document.getElementById('videoButton2').classList.add('btn-light-active-2', 'video-icon');
            document.getElementById('videoButton3').classList.remove('btn-light-active-3', 'video-icon');
            document.getElementById('first').style.border = '35px solid #000';
            break;
        case 'videoButton3':
            document.getElementById('videoButton1').classList.remove('btn-light-active-1', 'video-icon');
            document.getElementById('videoButton2').classList.remove('btn-light-active-2', 'video-icon');
            document.getElementById('videoButton3').classList.add('btn-light-active-3', 'video-icon');
            document.getElementById('first').style.border = '70px solid #000';
            break;

        default:
            break;
    }
}

function changeScreenLayout(sType) {
    if (!showVideo) {
        alert('please add your camera video feed.')
    }
    switch (sType) {
        case 'screenButton1':
            document.getElementById('screenButton1').classList.add('btn-screen-option-active', 'video-icon');
            document.getElementById('screenButton2').classList.remove('btn-screen-option-active', 'video-icon');
            document.getElementById('screenButton3').classList.remove('btn-screen-option-active', 'video-icon');
            document.getElementById('first').style.border = 'none';

            document.getElementById('second').style.visibility = 'visible';
            document.getElementById('second').classList.add('video-sm-image');
            document.getElementById('second').classList.remove('video-sm-image-left');

            document.getElementById('first').src = './screenshare.png';
            document.getElementById('screenLeft').style.visibility = 'hidden';
            document.getElementById('screenRight').style.visibility = 'hidden';
            break;
        case 'screenButton2':
            document.getElementById('screenButton1').classList.remove('btn-screen-option-active', 'video-icon');
            document.getElementById('screenButton2').classList.add('btn-screen-option-active', 'video-icon');
            document.getElementById('screenButton3').classList.remove('btn-screen-option-active', 'video-icon');
            // document.getElementById('first').style.border = '50px solid #000';
            document.getElementById('second').style.visibility = 'visible';
            document.getElementById('second').classList.remove('video-sm-image');
            document.getElementById('second').classList.add('video-sm-image-left');

            document.getElementById('first').src = './screenshare.png';
            document.getElementById('screenLeft').style.visibility = 'hidden';
            document.getElementById('screenRight').style.visibility = 'hidden';
            break;
        case 'screenButton3':
            document.getElementById('screenButton1').classList.remove('btn-screen-option-active', 'video-icon');
            document.getElementById('screenButton2').classList.remove('btn-screen-option-active', 'video-icon');
            document.getElementById('screenButton3').classList.add('btn-screen-option-active', 'video-icon');
            // document.getElementById('first').style.border = '80px solid #000';
            document.getElementById('second').style.visibility = 'hidden';

            document.getElementById('first').src = './black.png';
            document.getElementById('screenLeft').style.visibility = 'visible';
            document.getElementById('screenRight').style.visibility = 'visible';
            break;

        default:
            break;
    }
}
