######How to run app######
This app was built on HTML,CCS,JavaScript

To run this app.

unzip frontend-assigment folder to which ever place you want to extract it.

You can either just click the index.html file that is located in the frontend-assigment folder
or use visual studios and right click the index.html file and select Open with Live Server
This should take you to the application where you can test out the features


Let me know if you have any trouble running the application