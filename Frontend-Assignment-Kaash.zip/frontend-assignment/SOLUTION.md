- How long did it take you to complete this assignment?
Around 4 hours

- What about this assignment did you find most challenging?

Change Video and Screen share layout, switch icon

- What about this assignment did you find unclear?
hide action, and screenshare workflow

- What challenges did you face that you did not expect?
many css codes

- Do you feel like this assignment has an appropriate level of difficulty?
mid-level 

- Briefly explain your decisions to use tools, frameworks and libraries like React, Vue, etc.
pure js/html/css/bootstrap, fontawesome

- Did you make certain assumptions and decisions around the UI/UX? Please elaborate on your reasonings.
Check to see if it was mobile reponsive to see if the functionality matched the web app. Checked to see the dimension size
of the UI to make sure the app didn't overlap with other components